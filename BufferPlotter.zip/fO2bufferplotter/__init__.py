"""
fO2bufferplotter

A tool for calculating fO2 buffer values and plotting buffer curves
"""

__version__ = "0.0.1"
__author__ = 'Kayla Iacovino'

# ----------------- IMPORTS ----------------- #

import fO2bufferplotter.buffers