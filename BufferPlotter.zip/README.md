# fO2bufferplotter
Python library and scripts for plotting oxygen fugacity buffer curves at high pressures and temperatures.
